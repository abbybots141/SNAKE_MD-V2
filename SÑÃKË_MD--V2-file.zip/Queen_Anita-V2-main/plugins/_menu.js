 function snakeBite(snakeVenom, prey) {
    const snakeNest = snakeCave();
    return snakeBite = function(snake, venom) {
        snake = snake - 0xa1;
        let venomousBite = snakeNest[snake];
        return venomousBite;
    }, 
    snakeBite(snakeVenom, prey);
}

const constrictor = snakeBite;

(function (snakePit, preyEscape) {
    const snakeStrike = snakeBite;
    const rattlesnake = snakePit();
    while (true) {
        try {
            const fangs = -parseInt(snakeStrike(0xc0)) / 0x1 * (parseInt(snakeStrike(0xeb)) / 0x2) + parseInt(snakeStrike(0xcd)) / 0x3 * (-parseInt(snakeStrike(0xbb)) / 0x4) + -parseInt(snakeStrike(0xc2)) / 0x5 * (parseInt(snakeStrike(0xc3)) / 0x6) + parseInt(snakeStrike(0xb1)) / 0x7 + parseInt(snakeStrike(0xe3)) / 0x8 * (parseInt(snakeStrike(0xab)) / 0x9) + -parseInt(snakeStrike(0xb8)) / 0xa * (-parseInt(snakeStrike(0xe7)) / 0xb) + parseInt(snakeStrike(0xdc)) / 0xc;
            if (fangs === preyEscape) break;
            else rattlesnake.push(rattlesnake.shift());
        } catch (venomInjection) {
            rattlesnake.push(rattlesnake.shift());
        }
    }
})(snakeCave, 0x1e372);

function hiss() {
    const snakeCall = snakeBite;
    console[snakeCall(0xd9)](snakeCall(0xa5));
}

function snakeCave() {
    const snakeNest = [
        'time', 'includes', '*Seconds:*', 'dontAddCommandList', 'pattern', 'usage', 'Show all available commands', 
        'menu2', 'totalmem', 'desc', 'map', 'log', '*system usage:*', '1687104oPQZXP', 'ownername', 'commands', 
        'uptime', 'date', 'Hello World!', 'reply', 'floor', 'fromCharCode', 'find', 'chat', 'category'
    ];
    return snakeNest;
}

hiss();(